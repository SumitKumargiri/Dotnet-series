﻿namespace Dapper_pro.Code
{
    public class ConnectionStringList
    {
        public string ConnectionString1 { get; set; }
    }
}
