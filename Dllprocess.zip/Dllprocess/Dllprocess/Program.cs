using Dllprocess.Interface;
using Dllprocess.Services;
using Dllprocess.utility;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

string connectionString = builder.Configuration.GetConnectionString("ConnectionString1");

builder.Services.AddScoped<ICrud>(provider => new CrudService(connectionString));

// Pass both parameters to CrudService
//CrudService crudService = new CrudService(connectionString, dbGateway);

//builder.Services.AddScoped<ICrud>(provider =>
//{
//    var dBGateway = provider.GetRequiredService<IDBGateway>();
//    return new CrudService(connectionString, dBGateway);
//});



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();


app.UseRouting();
app.Run();
