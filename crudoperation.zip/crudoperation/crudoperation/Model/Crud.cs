﻿namespace crudoperation.Model
{
    public class Crud
    {
        public int id { get; set; }
        public string name { get; set; }
        public string email {  get; set; }
        public string country {  get; set; }
    }
}
